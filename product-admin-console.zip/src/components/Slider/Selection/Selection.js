import React from 'react'
import './Selection.scss'

const Selection = () => (<div className="mark" />)

export default Selection;
