import Slider from './Slider/Slider'

import Item from './Item/Item'

Slider.Item = Item;

export default Slider;
