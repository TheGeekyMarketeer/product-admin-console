import React from 'react'
import './Input.scss'

const Input = ({children}) =>{
    return (
        <input 
            class= 'react-autosuggest__input'
            type="text" 
            value=""/>
    )
}

export default Input
