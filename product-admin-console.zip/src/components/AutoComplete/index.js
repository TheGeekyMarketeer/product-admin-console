import AutoSuggest from './AutoSuggest/AutoSuggest'

export default AutoSuggest;
